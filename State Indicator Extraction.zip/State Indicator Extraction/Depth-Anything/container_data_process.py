import os
import cv2
import torch
import sys
import numpy as np
import json
from torchvision.transforms import Compose

# Dynamically add the depth_anything directory to the Python path
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'depth_anything'))

# Import modules
from depth_anything.dpt import DepthAnything
from depth_anything.util.transform import Resize, NormalizeImage, PrepareForNet

# Set parameters
encoder = 'vitl'
root_dir = "E:\\container\\test2"
output_base_dir = os.path.join(root_dir, "singledepthl")
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# Define categories
CLS_NAMES = ['broken','dent','scratch','rust','deformation','hole']

# Create the base output directory
os.makedirs(output_base_dir, exist_ok=True)

# Load the model
model_configs = {
    'vitl': {'encoder': 'vitl', 'features': 256, 'out_channels': [256, 512, 1024, 1024], 'use_bn': False,
             'use_clstoken': False, 'localhub': True},
    'vitb': {'encoder': 'vitb', 'features': 128, 'out_channels': [96, 192, 384, 768], 'use_bn': False,
             'use_clstoken': False, 'localhub': True},
    'vits': {'encoder': 'vits', 'features': 64, 'out_channels': [48, 96, 192, 384], 'use_bn': False,
             'use_clstoken': False, 'localhub': True}
}

depth_anything = DepthAnything(config=model_configs[encoder])
checkpoint_path = os.path.join('./checkpoints', f'depth_anything_{encoder}14.pth')
if os.path.exists(checkpoint_path):
    depth_anything.load_state_dict(torch.load(checkpoint_path, map_location=device))
else:
    raise FileNotFoundError(f"Model checkpoint not found at {checkpoint_path}")
depth_anything = depth_anything.to(device).eval()

# Image preprocessing transforms
transform = Compose([
    Resize(
        width=518,
        height=518,
        resize_target=False,
        keep_aspect_ratio=True,
        ensure_multiple_of=14,
        resize_method='lower_bound',
        image_interpolation_method=cv2.INTER_CUBIC,
    ),
    NormalizeImage(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    PrepareForNet(),
])

# Dictionary for collecting metrics
metrics_dict = {}
image_extensions = ('.jpg', '.jpeg', '.png', '.bmp')

def detect_main_direction(depth_normalized):
    """
    Determine the main direction of the depth map from the trend of the color bands (gradient direction).

    Parameters:
        depth_normalized (np.array): Normalized depth map (0-255, uint8)

    Returns:
        float: Main direction angle in degrees, ranging from [0, 180), where 0 indicates the horizontal direction
    """
    depth_blurred = cv2.GaussianBlur(depth_normalized, (5, 5), 0)
    grad_x = cv2.Sobel(depth_blurred, cv2.CV_64F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(depth_blurred, cv2.CV_64F, 0, 1, ksize=3)
    grad_magnitude = np.sqrt(grad_x ** 2 + grad_y ** 2)
    grad_angle = np.arctan2(grad_y, grad_x) * 180 / np.pi
    grad_angle = np.abs(grad_angle)
    grad_angle = np.where(grad_angle > 90, 180 - grad_angle, grad_angle)
    weights = grad_magnitude / (np.max(grad_magnitude) + 1e-10)
    weighted_angle = np.average(grad_angle, weights=weights)
    if np.mean(grad_magnitude) < 1e-2:
        return 0.0
    return weighted_angle

def calculate_boundary_transition_entropy(depth, main_direction):
    """
    Calculate boundary transition entropy to characterize color-band blending and overlap.

    Parameters:
        depth (np.array): Depth map (0-255, uint8)
        main_direction (float): Main direction angle in degrees

    Returns:
        float: Maximum boundary transition entropy
    """
    if depth.size == 0 or depth.size < 2:
        return 0.0
    theta_rad = main_direction * np.pi / 180
    h, w = depth.shape
    center = (w / 2, h / 2)
    M = cv2.getRotationMatrix2D(center, main_direction, 1.0)
    depth_rotated = cv2.warpAffine(depth, M, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)

    entropies = []
    for row in depth_rotated:
        transitions = np.diff(row)
        diff = np.abs(transitions)
        if diff.size == 0 or diff.max() <= 0:
            continue
        hist, bins = np.histogram(diff, bins=20, range=(0, max(diff.max(), 1e-10)), density=True)
        hist = hist / (hist.sum() + 1e-10)
        hist = hist[hist > 1e-10]
        if len(hist) == 0:
            continue
        entropy = -np.sum(hist * np.log2(hist + 1e-10))
        entropies.append(max(entropy, 0.0))
    return max(entropies) if entropies else 0.0

def calculate_gradient_strength_in_color_band_direction(depth, main_direction):
    """
    Calculate the gradient strength along the color-band variation direction.

    Parameters:
        depth (np.array): Depth map (0-255, uint8)
        main_direction (float): Main direction angle in degrees

    Returns:
        float: Gradient strength in the color-band direction (mean cosine value, 0-1)
    """
    print(f"Depth shape: {depth.shape}, min: {depth.min()}, max: {depth.max()}")
    if depth.size == 0:
        return 0.0
    grad_x = cv2.Sobel(depth, cv2.CV_64F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(depth, cv2.CV_64F, 0, 1, ksize=3)
    grad_magnitude = np.sqrt(grad_x ** 2 + grad_y ** 2)
    grad_angle = np.arctan2(grad_y, grad_x) * 180 / np.pi
    grad_angle = np.abs(grad_angle)
    grad_angle = np.where(grad_angle > 90, 180 - grad_angle, grad_angle)
    cos_diff = np.abs(np.cos((grad_angle - main_direction) * np.pi / 180))
    valid_mask = grad_magnitude > (np.max(grad_magnitude) * 0.1)
    if np.sum(valid_mask) == 0:
        print("No valid pixels for gradient strength calculation")
        return 0.0
    strength = np.mean(cos_diff[valid_mask])
    print(f"Gradient strength in color band direction: {strength:.4f}")
    return strength

# Iterate over each category
for cls_name in CLS_NAMES:
    cls_dir = os.path.join(root_dir, cls_name)
    if not os.path.exists(cls_dir):
        print(f"Warning: category directory {cls_dir} does not exist; skipping")
        continue

    input_base_dir = os.path.join(cls_dir, "image")
    output_dir = os.path.join(output_base_dir, cls_name)
    os.makedirs(output_dir, exist_ok=True)

    # Process Anomaly and Normal samples
    species = ['Anomaly', 'Normal']
    for specie in species:
        input_dir = os.path.join(input_base_dir, specie)
        if not os.path.exists(input_dir):
            print(f"Input directory not found: {input_dir}")
            continue
        image_files = [f for f in os.listdir(input_dir) if f.lower().endswith(image_extensions)]
        image_files.sort()

        for image_file in image_files:
            print(f"Processing {cls_name}/{specie}/{image_file}...")
            try:
                image_path = os.path.join(input_dir, image_file)
                if not os.path.exists(image_path):
                    print(f"Skipping {image_file}: File not found")
                    continue
                image = cv2.cvtColor(cv2.imread(image_path), cv2.COLOR_BGR2RGB) / 255.0

                # Preprocess the image and generate the depth map
                image_transformed = transform({'image': image})['image']
                image_transformed = torch.from_numpy(image_transformed).unsqueeze(0).to(device)
                with torch.no_grad():
                    depth = depth_anything(image_transformed)
                depth = depth.squeeze().cpu().numpy()
                depth_normalized = cv2.normalize(depth, None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX,
                                                dtype=cv2.CV_8U)
                depth_normalized = np.clip(depth_normalized, 0, 255).astype(np.uint8)

                # Save the depth map
                output_path = os.path.join(output_dir, f"depth_{specie}_{image_file}")
                cv2.imwrite(output_path, depth_normalized)
                print(f"Saved depth map to {output_path}")

                depth_colored = cv2.applyColorMap(depth_normalized, cv2.COLORMAP_JET)
                cv2.imwrite(os.path.join(output_dir, f"depth_colored_{specie}_{image_file}"), depth_colored)
                print(f"Saved colored depth map to {os.path.join(output_dir, f'depth_colored_{specie}_{image_file}')}")

                # Detect the main direction
                main_direction = detect_main_direction(depth_normalized)
                print(f"Main direction angle: {main_direction:.2f} degrees")

                # Calculate metrics
                boundary_transition_entropy = calculate_boundary_transition_entropy(depth_normalized, main_direction)
                gradient_strength_in_color_band = calculate_gradient_strength_in_color_band_direction(depth_normalized, main_direction)

                print(f"Depth value range: [{depth_normalized.min():.2f}, {depth_normalized.max():.2f}], "
                      f"Main direction: {main_direction:.2f}°, boundary transition entropy: {boundary_transition_entropy:.4f}, "
                      f"gradient strength in color-band direction: {gradient_strength_in_color_band:.4f}")

                # Store the metrics in the dictionary
                rel_path = f"{cls_name}/image/{specie}/{image_file}"
                metrics_dict[rel_path] = {
                    'Main Direction': f"{main_direction:.2f}",
                    'Boundary Transition Entropy': f"{boundary_transition_entropy:.4f}",
                    'Gradient Strength in Color Band Direction': f"{gradient_strength_in_color_band:.4f}"
                }

            except Exception as e:
                print(f"Error processing {image_file}: {str(e)}")

# Save metrics to JSON
metrics_path = os.path.join(root_dir, 'depth_metrics.json')
with open(metrics_path, 'w') as f:
    json.dump(metrics_dict, f, indent=4)

print("Batch processing completed!")