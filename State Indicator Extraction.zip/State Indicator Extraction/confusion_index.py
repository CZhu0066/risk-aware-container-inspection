# Six category indicators
import pandas as pd
import json
import os

# Define six categories
CATEGORIES = ['broken', 'dent', 'scratch', 'rust', 'deformation', 'hole']

def get_category(image_path):

    path = str(image_path).replace('\\', '/')
    for cat in CATEGORIES:
        if cat in path:
            return cat
    return 'Other'

def merge_depth_features(csv_path, json_paths, output_path, debug=True):

    df = pd.read_csv(csv_path)

    if debug:
        # print("=" * 60)
        # print("CSV file information:")
        # print(f"Total rows: {len(df)}")
        # print(f"Column names: {list(df.columns)}")


        category_counts = {cat: 0 for cat in CATEGORIES}
        category_counts['Other'] = 0
        for img_path in df['Image_Path']:
            cat = get_category(img_path)
            category_counts[cat] += 1


        for cat in CATEGORIES:
            print(f"  {cat}: {category_counts[cat]}")
        print(f"  Other: {category_counts['Other']}")

        print("\nCSV Image_Path:")
        for i, path in enumerate(df['Image_Path'].head(5)):
            normalized_path = path.replace('\\', '/')
            cat = get_category(path)
            print(f"  {i+1}. [{cat}] {normalized_path}")
        print("=" * 60)


    df['Boundary_Transition_Entropy'] = 0.0
    df['Gradient_Strength_in_Color_Band_Direction'] = 0.0


    all_depth_metrics = {}
    for json_path in json_paths:
        if os.path.exists(json_path):
            try:
                with open(json_path, 'r', encoding='utf-8') as f:
                    metrics = json.load(f)
                    all_depth_metrics.update(metrics)
                    print(f"Successfully loaded JSON file: {json_path}, containing {len(metrics)} records")
                    if debug:
                        print("First 3 JSON keys:")
                        for i, key in enumerate(list(metrics.keys())[:3]):
                            print(f"  {i+1}. {key}")
            except Exception as e:
                print(f" Failed to load JSON file {json_path}: {e}")
        else:
            print(f"JSON file does not exist: {json_path}")


    depth_map = {}
    for rel_path, metrics in all_depth_metrics.items():
        try:
            depth_map[rel_path] = {
                'Boundary_Transition_Entropy': float(metrics.get('Boundary Transition Entropy', 0.0)),
                'Gradient_Strength_in_Color_Band_Direction': float(
                    metrics.get('Gradient Strength in Color Band Direction', 0.0)
                )
            }
        except Exception as e:
            print(f"Error processing path {rel_path}: {e}")
            depth_map[rel_path] = {
                'Boundary_Transition_Entropy': 0.0,
                'Gradient_Strength_in_Color_Band_Direction': 0.0
            }

    if debug:
        print(f"depth_map contains {len(depth_map)} mapping entries")
        print("First 3 keys in depth_map:")
        for i, key in enumerate(list(depth_map.keys())[:3]):
            print(f"  {i+1}. {key}")

    # 5. Match and fill data (regardless of category, based only on path)
    def extract_relative_path(full_path, debug_this=False):
        """Extract the relative path while preserving the original logic and remaining category-independent."""
        original_path = str(full_path)
        normalized = original_path.replace('\\', '/').strip()
        parts = normalized.split('/')

        if debug_this:
            print(f"\nProcessing path: {original_path}")
            print(f"   Normalized: {normalized}")
            print(f"   Split parts: {parts}")

        # Prioritize the 'testRM' directory
        if 'testRM' in parts:
            idx = parts.index('testRM')
            remaining_parts = parts[idx+1:]
            if debug_this:
                print(f"   Found 'testRM'; remaining parts: {remaining_parts}")
            result = '/'.join(remaining_parts)
            if debug_this:
                print(f"   Relative path: {result}")
            return result

        # Other common target directories (fallback)
        for target in ['test2', 'test1', 'images', 'data', 'real_test', 'test', 'bianyuancaiji']:
            if target in parts:
                idx = parts.index(target)
                result = '/'.join(parts[idx+1:])
                if debug_this:
                    print(f"   Found target directory '{target}'; relative path: {result}")
                return result

        if debug_this:
            print("Unable to extract relative path")
        return None

    # Initialize statistics by category
    total_counts = {cat: 0 for cat in CATEGORIES}
    matched_counts = {cat: 0 for cat in CATEGORIES}
    total_counts['Other'] = 0
    matched_counts['Other'] = 0

    print("\nStarting data matching...")

    for idx, row in df.iterrows():
        show_debug = debug and (idx < 3)

        rel_path = extract_relative_path(row['Image_Path'], debug_this=show_debug)
        img_path_str = str(row['Image_Path'])
        cat = get_category(img_path_str)   # Get the category of the current image

        total_counts[cat] += 1

        if rel_path and rel_path in depth_map:
            # Match successful
            df.at[idx, 'Boundary_Transition_Entropy'] = depth_map[rel_path]['Boundary_Transition_Entropy']
            df.at[idx, 'Gradient_Strength_in_Color_Band_Direction'] = depth_map[rel_path]['Gradient_Strength_in_Color_Band_Direction']
            matched_counts[cat] += 1
            if show_debug:
                print(f"Match successful! (Category: {cat})")
        else:
            # No match: keep the default value of 0.0
            if show_debug:
                if rel_path:
                    print(f"No match found: {rel_path} (Category: {cat})")
                else:
                    print(f"Unable to extract relative path (Category: {cat})")

    # 6. Save results
    df.to_csv(output_path, index=False)

    print(f"\n" + "=" * 60)
    print("Processing completed!")
    print(f"   Total records: {len(df)}")
    print("   Path category statistics:")
    for cat in CATEGORIES:
        print(f"     {cat}: {total_counts[cat]}")
    print(f"     Other: {total_counts['Other']}")
    print("   Matching results:")
    for cat in CATEGORIES:
        print(f"     {cat}: {matched_counts[cat]}/{total_counts[cat]}")
    print(f"     Other: {matched_counts['Other']}/{total_counts['Other']}")
    print(f"   Saved to: {output_path}")

    # Validate data (first 5 rows)
    if debug:
        print("\n Data validation (first 5 rows):")
        for i in range(min(5, len(df))):
            row = df.iloc[i]
            img_path_str = str(row['Image_Path'])
            cat = get_category(img_path_str)
            normalized_path = img_path_str.replace('\\', '/')
            bt = row['Boundary_Transition_Entropy']
            gs = row['Gradient_Strength_in_Color_Band_Direction']
            print(f"  Row {i+1}: {cat} - BT={bt}, GS={gs} - {normalized_path}")

    # Count non-zero values
    non_zero_bt = (df['Boundary_Transition_Entropy'] > 0).sum()
    non_zero_gs = (df['Gradient_Strength_in_Color_Band_Direction'] > 0).sum()
    print("\nNon-zero value statistics:")
    print(f"   Boundary_Transition_Entropy non-zero values: {non_zero_bt}")
    print(f"   Gradient_Strength_in_Color_Band_Direction non-zero values: {non_zero_gs}")

    total_matched = sum(matched_counts.values())
    if total_matched != len(depth_map):
        print("\n  Note:")
        print(f"   JSON contains {len(depth_map)} records, but only {total_matched} were matched")
        if total_matched < len(depth_map):
            print("   Possible reason: some images are missing from the CSV")
        else:
            print("   Possible reason: the CSV contains duplicate image paths")

    print("=" * 60)
    return df


def quick_check(csv_path, json_path):
    """
    Quickly check the path formats of the CSV and JSON files for the six categories
    """
    print(" Quick path format check")
    print("=" * 60)

    df = pd.read_csv(csv_path)
    print(f"CSV file: {csv_path}")
    print(f"Number of rows: {len(df)}")

    # Count samples in each category
    category_counts = {cat: 0 for cat in CATEGORIES}
    category_counts['Other'] = 0
    for img_path in df['Image_Path']:
        cat = get_category(img_path)
        category_counts[cat] += 1

    print("\nPath category statistics:")
    for cat in CATEGORIES:
        print(f"  {cat}: {category_counts[cat]}")
    print(f"  Other: {category_counts['Other']}")

    # Show examples for each category
    for cat in CATEGORIES:
        paths = df[df['Image_Path'].apply(lambda p: cat in str(p).replace('\\', '/'))]
        if len(paths) > 0:
            print(f"\n{cat} path examples (first 3):")
            for i in range(min(3, len(paths))):
                path = paths.iloc[i]['Image_Path']
                normalized_path = path.replace('\\', '/')
                print(f"  {i+1}. {normalized_path}")

    print("\n" + "-" * 40)

    with open(json_path, 'r', encoding='utf-8') as f:
        metrics = json.load(f)

    print(f"JSON file: {json_path}")
    print(f"Number of records: {len(metrics)}")
    print("\nJSON key examples:")
    keys = list(metrics.keys())
    for i in range(min(3, len(keys))):
        key = keys[i]
        print(f"  {i+1}. {key}")

    print("\nLast JSON key:")
    print(f"  {keys[-1]}")

    # Check whether the JSON contains category subdirectories
    category_in_json = {cat: any(cat in key for key in keys) for cat in CATEGORIES}
    print("\nJSON key analysis (whether category directories are included):")
    for cat in CATEGORIES:
        print(f"  {cat}: {'Yes' if category_in_json[cat] else 'No'}")

    print("=" * 60)
    return df, metrics


# Usage example
if __name__ == "__main__":
    csv_path = "E:\\container\\test2\\test2_results.csv"
    json_path = "E:\\container\\test2\\depth_metrics.json"

    print(" Running quick check...")
    df_check, json_check = quick_check(csv_path, json_path)

    continue_process = input("\nContinue with the main processing workflow? (y/n): ")
    if continue_process.lower() == 'y':
        print("\n Running main processing workflow...")
        merge_depth_features(
            csv_path=csv_path,
            json_paths=[json_path],
            output_path="E:\\container\\test2\\merged.csv",
            debug=True
        )
    else:
        print("Main processing workflow stopped")